package com.vahini.service;

public interface RegisterService {
	boolean insertUser(String name, String email, String password );
}
